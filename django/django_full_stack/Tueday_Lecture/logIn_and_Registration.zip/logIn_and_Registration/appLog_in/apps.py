from django.apps import AppConfig


class ApplogInConfig(AppConfig):
    name = 'appLog_in'
