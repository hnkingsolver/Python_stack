from django.apps import AppConfig


class AppBeltExamConfig(AppConfig):
    name = 'app_belt_exam'
