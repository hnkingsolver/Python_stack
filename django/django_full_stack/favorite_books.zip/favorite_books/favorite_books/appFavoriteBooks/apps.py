from django.apps import AppConfig


class AppfavoritebooksConfig(AppConfig):
    name = 'appFavoriteBooks'
