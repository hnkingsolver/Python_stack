from django.apps import AppConfig


class AppbeltexamConfig(AppConfig):
    name = 'appBeltExam'
