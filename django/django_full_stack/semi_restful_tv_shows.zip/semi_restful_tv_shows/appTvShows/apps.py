from django.apps import AppConfig


class ApptvshowsConfig(AppConfig):
    name = 'appTvShows'
