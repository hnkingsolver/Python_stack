from django.apps import AppConfig


class YaydjangoConfig(AppConfig):
    name = 'yayDjango'
