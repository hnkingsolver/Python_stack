from django.apps import AppConfig


class ApprandomwordConfig(AppConfig):
    name = 'appRandomWord'
