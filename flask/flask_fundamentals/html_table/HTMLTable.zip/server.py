from flask import Flask, render_template
app = Flask(__name__)



@app.route("/table")
def users():
    users = [
        {'first_name': 'Hannah', 'last_name': 'Kingsolver', 'entry_number': '1'},
        {'first_name': 'Tanner', 'last_name': 'Colley', 'entry_number': '2'},
        {'first_name': 'Spongebob', 'last_name': 'Squarepants', 'entry_number': '3'},
        {'first_name': 'Patrick', 'last_name': 'Star', 'entry_number': '4'}
    ]

    return render_template("htmltable.html", users=users)


if __name__ == "__main__":
    app.run(debug=True)
